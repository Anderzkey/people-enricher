package handler

import (
	"log"
	"net/http"
	"people-enricher/internal/client"
	"people-enricher/internal/model"
	"people-enricher/internal/repository"
	"strconv"

	"github.com/gin-gonic/gin"
)

type PersonHandler struct {
	repo *repository.PersonRepository
}

func NewPersonHandler(repo *repository.PersonRepository) *PersonHandler {
	return &PersonHandler{repo: repo}
}

// @Summary Добавить человека
// @Description Принимает ФИО, обогащает и сохраняет
// @Tags people
// @Accept json
// @Produce json
// @Param person body model.Person true "Человек"
// @Success 200 {object} model.Person
// @Failure 400 {object} map[string]string
// @Router /people [post]

func (h *PersonHandler) CreatePerson(c *gin.Context) {
	var input struct {
		Name       string `json:"name" binding:"required"`
		Surname    string `json:"surname" binding:"required"`
		Patronymic string `json:"patronymic"`
	}

	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	age, _ := client.GetAge(input.Name)
	gender, _ := client.GetGender(input.Name)
	nat, _ := client.GetNationality(input.Name)

	person := &model.Person{
		Name:        input.Name,
		Surname:     input.Surname,
		Patronymic:  input.Patronymic,
		Age:         age,
		Gender:      gender,
		Nationality: nat,
	}

	err := h.repo.Create(person)
	if err != nil {
		log.Printf("DB insert error: %v\n", err) // добавим лог
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to save person"})
		return
	}

	c.JSON(http.StatusOK, person)
}

// @Summary      Получить список людей
// @Description  Получает всех людей с возможностью фильтрации и пагинации
// @Tags         people
// @Accept       json
// @Produce      json
// @Param        name query string false "Имя для фильтрации"
// @Param        surname query string false "Фамилия для фильтрации"
// @Param        page query int false "Номер страницы"
// @Param        limit query int false "Кол-во элементов на странице"
// @Success      200 {array} model.Person
// @Failure      500 {object} map[string]string
// @Router       /people [get]

func (h *PersonHandler) GetPeople(c *gin.Context) {
	name := c.Query("name")
	surname := c.Query("surname")
	gender := c.Query("gender")

	// Пагинация
	limitStr := c.DefaultQuery("limit", "10")
	offsetStr := c.DefaultQuery("offset", "0")

	limit, err := strconv.Atoi(limitStr)
	if err != nil || limit <= 0 {
		limit = 10
	}
	offset, err := strconv.Atoi(offsetStr)
	if err != nil || offset < 0 {
		offset = 0
	}

	people, err := h.repo.GetAll(name, surname, gender, limit, offset)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "cannot fetch people"})
		return
	}

	c.JSON(http.StatusOK, people)
}

// @Summary      Удалить человека
// @Description  Удаляет запись по ID
// @Tags         people
// @Accept       json
// @Produce      json
// @Param        id path int true "ID человека"
// @Success      200 {object} map[string]string
// @Failure      400 {object} map[string]string
// @Failure      500 {object} map[string]string
// @Router       /people/{id} [delete]

func (h *PersonHandler) DeletePerson(c *gin.Context) {
	idParam := c.Param("id")
	id, err := strconv.Atoi(idParam)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	err = h.repo.Delete(id)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to delete person"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "person deleted"})
}

// @Summary      Обновить человека
// @Description  Обновляет запись человека по ID
// @Tags         people
// @Accept       json
// @Produce      json
// @Param        id path int true "ID человека"
// @Param        person body model.Person true "Обновлённые данные"
// @Success      200 {object} map[string]string
// @Failure      400 {object} map[string]string
// @Failure      500 {object} map[string]string
// @Router       /people/{id} [put]

func (h *PersonHandler) UpdatePerson(c *gin.Context) {
	idParam := c.Param("id")
	id, err := strconv.Atoi(idParam)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid id"})
		return
	}

	var input model.Person
	if err := c.ShouldBindJSON(&input); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "invalid JSON"})
		return
	}

	input.ID = int64(id) // Устанавливаем ID явно
	err = h.repo.Update(&input)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": "failed to update person"})
		return
	}

	c.JSON(http.StatusOK, gin.H{"message": "person updated"})
}
