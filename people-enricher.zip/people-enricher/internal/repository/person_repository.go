package repository

import (
	"people-enricher/internal/model"

	"github.com/jmoiron/sqlx"
)

type PersonRepository struct {
	db *sqlx.DB
}

func NewPersonRepository(db *sqlx.DB) *PersonRepository {
	return &PersonRepository{db: db}
}

func (r *PersonRepository) Create(person *model.Person) error {
	query := `
	INSERT INTO people (name, surname, patronymic, age, gender, nationality)
		VALUES (:name, :surname, :patronymic, :age, :gender, :nationality)
		RETURNING id, created_at, updated_at
	`
	rows, err := r.db.NamedQuery(query, person)
	if err != nil {
		return err
	}
	defer rows.Close()

	if rows.Next() {
		err = rows.Scan(&person.ID, &person.CreatedAt, &person.UpdatedAt)
	}
	return err
}

func (r *PersonRepository) GetAll(name, surname, gender string, limit, offset int) ([]model.Person, error) {
	query := `
		SELECT * FROM people
		WHERE 
			($1 = '' OR name ILIKE '%' || $1 || '%') AND
			($2 = '' OR surname ILIKE '%' || $2 || '%') AND
			($3 = '' OR gender = $3)
		ORDER BY created_at DESC
		LIMIT $4 OFFSET $5
	`
	var people []model.Person
	err := r.db.Select(&people, query, name, surname, gender, limit, offset)
	return people, err
}

func (r *PersonRepository) Delete(id int) error {
	query := `DELETE FROM people WHERE id = $1`
	_, err := r.db.Exec(query, id)
	return err
}

func (r *PersonRepository) Update(p *model.Person) error {
	query := `
        UPDATE people 
        SET name = $1, surname = $2, patronymic = $3, age = $4, gender = $5, nationality = $6
        WHERE id = $7
    `
	_, err := r.db.Exec(query,
		p.Name,
		p.Surname,
		p.Patronymic,
		p.Age,
		p.Gender,
		p.Nationality,
		p.ID,
	)
	return err
}
