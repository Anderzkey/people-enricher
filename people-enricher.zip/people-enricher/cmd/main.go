// @title People Enricher API
// @version 1.0
// @description API для добавления, обновления, удаления и просмотра обогащённых данных людей
// @host localhost:8080
// @BasePath /

package main

import (
	"log"
	"people-enricher/config"
	"people-enricher/internal/handler"
	"people-enricher/internal/repository"

	"github.com/gin-gonic/gin"
	"github.com/jmoiron/sqlx"
	_ "github.com/lib/pq"

	_ "people-enricher/cmd/docs"

	swaggerFiles "github.com/swaggo/files"
	ginSwagger "github.com/swaggo/gin-swagger"
)

func main() {
	cfg := config.LoadConfig()

	db, err := sqlx.Connect("postgres", cfg.DBURL)
	if err != nil {
		log.Fatalf("DB connection failed: %v", err)
	}
	defer db.Close()

	repo := repository.NewPersonRepository(db)
	h := handler.NewPersonHandler(repo)

	r := gin.Default()
	r.POST("/people", h.CreatePerson)
	r.GET("/people", h.GetPeople)
	r.DELETE("/people/:id", h.DeletePerson)
	r.PUT("/people/:id", h.UpdatePerson)
	r.GET("/swagger/*any", ginSwagger.WrapHandler(swaggerFiles.Handler))

	log.Println("Server started on port", cfg.Port)
	r.Run(":" + cfg.Port)
}
